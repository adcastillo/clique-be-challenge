<section id="about">
    <div class="home__about">
        <div class="home__about__container">
            <div class="home__about__intro">
                <h2>About Us</h2>
            </div>
            <div class="home__about__studies">
                <div class="home__about__studies__item">
                    <div class="home__about__studies__item__logo__container">
                        <img role="img" src="https://focus.cliquedomains.com/app/uploads/2021/02/split-content-image.jpg" data-src="https://focus.cliquedomains.com/app/uploads/2021/02/split-content-image.jpg" alt="split-content-image" property="v:image" content="https://focus.cliquedomains.com/app/uploads/2021/02/split-content-image.jpg">
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt tortor felis, et iaculis
                        libero tincidunt quis. Mauris ex augue, laoreet vitae porttitor et, maximus a ante. Mauris sed
                        tellus pretium lacus tempor iaculis at a arcu. Aliquam a ultricies enim. Etiam tincidunt justo
                        non quam sodales sagittis.</p>
                </div>
            </div>
        </div>
    </div>

</section>
<?php /**PATH /Users/fbouyer/dev/web/php/sites/be-code-challenge/web/app/themes/be-challenge-theme/resources/views/partials/home-about.blade.php ENDPATH**/ ?>